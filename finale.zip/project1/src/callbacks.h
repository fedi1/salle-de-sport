#include <gtk/gtk.h>

void on_button10_clicked (GtkWidget *object_graphique , gpointer user_data);
//void on_button8_clicked(GtkWidget *objet_graphique , gpointer user_data);
//void on_button6_clicked(GtkWidget *objet_graphique,gpointer user_data);

void
on_button_medecin_clicked              (GtkWidget *objet_graphique,gpointer user_data);


void
on_button21_clicked                    (GtkWidget *objet_graphique,gpointer user_data);


void
on_button4_clicked                     (GtkWidget *objet_graphique,gpointer user_data);

void
on_button31_clicked                    (GtkButton *objet_graphique, gpointer user_data);

void
on_button12_clicked                    (GtkButton *objet_graphique,gpointer user_data);

void
on_button15_clicked                    (GtkButton *objet_graphique,gpointer user_data);

void
on_button13_clicked                    (GtkButton *objet_graphique,gpointer user_data);

void
on_button14_clicked                    (GtkButton *objet_graphique,gpointer user_data);

void
on_button32_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
/*
void
on_button24_clicked                    (GtkButton       *button,
                                 gpointer         user_data);*/

void
on_button33_clicked                    (GtkButton       *button,
                                        gpointer         user_data); 

void
on_button28_clicked                    (GtkButton *objet_graphique,gpointer user_data);

void
on_button29_clicked                    (GtkWidget *objet_graphique,gpointer user_data);

void
on_button19_clicked                    (GtkWidget *objet_graphique,gpointer user_data);

void
on_button34_clicked                    (GtkWidget *objet_graphique,gpointer user_data);

void
on_button35_clicked                    (GtkWidget *objet_graphique,gpointer user_data);
/*
void
on_button1_clicked                     (GtkWidget *objet_graphique,gpointer user_data);

void
on_valider_clicked                     (GtkWidget *objet_graphique,gpointer user_data);

/*void
on__clicked                            (GtkWidget *objet_graphique,gpointer user_data);

void
on_button25_clicked                    (GtkWidget *objet_graphique,gpointer user_data);*/
