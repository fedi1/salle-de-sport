#ifndef COACH_H_INCLUDED
#define COACH_H_INCLUDED

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



struct Coach
{

   char ID[50];
   char password[50];
   char role[50];
   char nom[50];
   char prenom[50];
 
};
typedef struct Coach Coach;

void ajouter_coach();
int modifier_coach();
int rechercher_coach();
void supprimer_coach();
int verifier_coach();
void afficher_coach(GtkWidget *treeview2);
#endif
