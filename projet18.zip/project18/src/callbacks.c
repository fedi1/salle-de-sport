#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "adherent.h"
#include "adh.h"


void
on_button1_clicked (GtkWidget *objet_graphique,gpointer user_data)
{
	GtkWidget *log;
	GtkWidget *input_log;
	GtkWidget *output;
	GtkWidget *input_pass;
	GtkWidget *window_esace_adherent;
	GtkWidget *window_espace_admin;
	GtkWidget *window_espace_authentification;
	GtkWidget *window3;
	char logc[30];
	char passc[30];
	char error[100];

	log=lookup_widget(objet_graphique,"window_espace_authentification");
	input_log=lookup_widget(objet_graphique,"entry1");
	input_pass=lookup_widget(objet_graphique,"entry2");

	strcpy(logc,gtk_entry_get_text(GTK_ENTRY(input_log)));
	strcpy(passc,gtk_entry_get_text(GTK_ENTRY(input_pass)));

	if(verifierlog(logc,passc)==1){
	gtk_widget_hide(log);
	GtkWidget *window_espace_admin;
	window_espace_admin=create_window_espace_admin();
	gtk_widget_show (window_espace_admin);}

	else if(verifierlog(logc,passc)==2){
	gtk_widget_hide(log);
	GtkWidget *window_espace_adherent;
	FILE *f;
	f=fopen("ad.txt","a+");
        if(f!=NULL)
        { 
	fprintf(f,"%s \n",input_log);
	fclose(f);
	}
	else
	{
	return 0;
	}
	window_espace_adherent=create_window_espace_adherent();
	gtk_widget_show (window_espace_adherent);}
	
	if(verifierlog(logc,passc)==3){
	gtk_widget_hide(log);
	GtkWidget *window3;
	window3=create_window3();
	gtk_widget_show (window3);}

	else if(verifierlog(logc,passc)==-1){
	strcpy(error,"Vos informations sont invalides !!");
	output=lookup_widget(objet_graphique,"label4");
	gtk_label_set_text(GTK_LABEL(output),error);}
	
}


void
on_button2_clicked(GtkWidget *objet_graphique,gpointer user_data)

{
	GtkWidget *window_espace_admin;
	GtkWidget *window_gestion_adherent;
	window_espace_admin=lookup_widget(objet_graphique,"window_espace_admin");
	gtk_widget_hide(window_espace_admin);
	window_gestion_adherent=create_window_gestion_adherent();
	gtk_widget_show (window_gestion_adherent);
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button9_clicked (GtkWidget *objet_graphique,gpointer user_data)

{
	Adherent A;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *comboboxentry1;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *output;
	char error[100];
	char valide[100];
	char num[100];
	char nom[100];
	char test[30];
	int i;

	strcpy(test,"adherent");

	input1=lookup_widget(objet_graphique,"entry5");
	input2=lookup_widget(objet_graphique,"entry6");
	comboboxentry1=lookup_widget(objet_graphique,"comboboxentry1");
	input4=lookup_widget(objet_graphique,"entry3");
	input5=lookup_widget(objet_graphique,"entry4");
	output=lookup_widget(objet_graphique,"label22");

	strcpy(A.ID,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(A.password,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(A.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry1)));
	strcpy(A.nom,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(A.prenom,gtk_entry_get_text(GTK_ENTRY(input5)));

	strcpy(error,"Adherent existe déja");
	strcpy(valide,"Opération Réussite!");
	strcpy(num,"Rôle invalide! Réessayez S.V.P.");
	strcpy(nom,"ID invalide! Réessayez S.V.P.");
	

	if (verifier(A.ID)==1)
	{
		gtk_label_set_text(GTK_LABEL(output),error);
	}
	else if ((strlen(A.ID)<10))
	{
		gtk_label_set_text(GTK_LABEL(output),nom);
	}
	else if (strcmp(A.role,"2")!=0)
	{
		gtk_label_set_text(GTK_LABEL(output),num);
	}
	else
	{
		for (i=0;i<8;i++)
		
			test[i] = A.ID[i];
		
		if ((strcmp(test,"adherent")==0)&&(verifier(A.ID)==0))
		{
			ajouter_adherent (A);
			gtk_label_set_text(GTK_LABEL(output),valide);
		}
		else if (strcmp(test,"adherent")!=0)
		{
			gtk_label_set_text(GTK_LABEL(output),nom);
		}
	}
}


void
on_button10_clicked(GtkWidget *objet_graphique,gpointer  user_data)

{
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *output;

	input1=lookup_widget(objet_graphique,"entry5");
	input2=lookup_widget(objet_graphique,"entry6");
	input3=lookup_widget(objet_graphique,"comboboxentry1");
	input4=lookup_widget(objet_graphique,"entry3");
	input5=lookup_widget(objet_graphique,"entry4");
	output=lookup_widget(objet_graphique,"label22");

	gtk_entry_set_text (GTK_ENTRY (input1), "");
	gtk_entry_set_text (GTK_ENTRY (input2), "");
	gtk_entry_set_text (GTK_ENTRY (input3), "2");
	gtk_entry_set_text (GTK_ENTRY (input4), "");
	gtk_entry_set_text (GTK_ENTRY (input5), "");
}

void
on_button12_clicked (GtkWidget *objet_graphique,gpointer user_data)

{
	GtkWidget *input;
	GtkWidget *output;
	char id[50];
	char error[50];
	char succes[70];
	input=lookup_widget(objet_graphique,"entry8");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	if (verifier(id)==1)
	{
		supprimer_adherent(id);
		strcpy(succes,"Suppression effectuée avec succès");
		output=lookup_widget(objet_graphique,"label28");
		gtk_label_set_text(GTK_LABEL(output),succes);
	}
	else if (verifier(id)==0)
	{
		strcpy(error,"Adherent inexistant! Vérifiez S.V.P.");
		output=lookup_widget(objet_graphique,"label28");
		gtk_label_set_text(GTK_LABEL(output),error);
	}
}

void
on_button13_clicked(GtkWidget *objet_graphique,gpointer user_data)

{
	char id[50];
	GtkWidget *input;
	GtkWidget *output;
	char error[50];
	char succes[70];
	int l;
	input=lookup_widget(objet_graphique,"entry9");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	if (verifier(id)==1)
	{
		l=rechercher_adherent(id);
		strcpy(succes,"L'adherent portant cet ID est dans notre base");
		output=lookup_widget(objet_graphique,"label30");
		gtk_label_set_text(GTK_LABEL(output),succes);
	}
	else if (verifier(id)==0)
	{
		strcpy(error,"Adherent inexistant! Vérifiez S.V.P.");
		output=lookup_widget(objet_graphique,"label30");
		gtk_label_set_text(GTK_LABEL(output),error);
	}
}

void
on_button14_clicked (GtkButton  *button,gpointer  user_data)
{

GtkWidget *window_treeview1;



window_treeview1 = create_window_treeview1();
gtk_widget_show (window_treeview1);

GtkWidget *treeview1;


treeview1 = lookup_widget(window_treeview1,"treeview1");
afficher_adherent(treeview1);
gtk_window_set_position(GTK_WINDOW(window_treeview1),GTK_WIN_POS_CENTER);
gtk_widget_show(window_treeview1);

}

void
on_button8_clicked (GtkWidget *objet_graphique,gpointer user_data)
{
	GtkWidget *window_espace_admin;
	GtkWidget *window_gestion_adherent;
	window_gestion_adherent=lookup_widget(objet_graphique,"window_gestion_adherent");
	gtk_widget_hide(window_gestion_adherent);
	window_espace_admin=create_window_espace_admin();
	gtk_widget_show (window_espace_admin);
}

void
on_button15_clicked  (GtkWidget *objet_graphique,gpointer user_data)
{
	Adherent P;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *output;
	char valide[100];
	char num[100];
	char nom[100];
	
	input1=lookup_widget(objet_graphique,"entry10");
	input2=lookup_widget(objet_graphique,"entry13");
	input3=lookup_widget(objet_graphique,"entry14");
	input4=lookup_widget(objet_graphique,"entry11");
	input5=lookup_widget(objet_graphique,"entry12");
	output=lookup_widget(objet_graphique,"label40");
	strcpy(P.ID,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(P.password,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(P.role,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(P.nom,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(P.prenom,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(valide,"opération réussie");
	strcpy(num,"Rôle invalide! Réessayez S.V.P.");
	strcpy(nom,"ID invalide! Réessayez S.V.P.");
	
	if (strcmp(P.role,"2")!=0)
	{
		gtk_label_set_text(GTK_LABEL(output),num);
	}
	else
	{
		modifier_adherent (P);
		gtk_label_set_text(GTK_LABEL(output),valide);
	}
}

void
on_button16_clicked (GtkWidget  *button,gpointer  user_data)

{
	GtkWidget *window_gestion_adherent;
	GtkWidget *window_modifier_adherent;
	window_modifier_adherent=lookup_widget(button,"window_modifier_adherent");
	gtk_widget_hide(window_modifier_adherent);
	window_gestion_adherent=create_window_gestion_adherent();
	gtk_widget_show (window_gestion_adherent);
}


void
on_button28_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window_profil;
	GtkWidget *window_espace_adherent;
	
	
	window_espace_adherent=lookup_widget(objet_graphique,"window_espace_adherent");
	window_profil=lookup_widget(objet_graphique,"window_profil");
	gtk_widget_hide(window_espace_adherent);
	window_profil = create_window_profil ();
  	gtk_widget_show (window_profil);
	
}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button31_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *window_profil;
	GtkWidget *window_espace_adherent;
	window_espace_adherent=lookup_widget(objet_graphique,"window_espace_adherent");
	window_profil=lookup_widget(objet_graphique,"window_profil");
	gtk_widget_hide(window_profil);
	window_espace_adherent = create_window_espace_adherent ();
  	gtk_widget_show (window_espace_adherent);
}


void
on_button32_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
adherent p ;
	char id1[50];
	char id[50];
	char nom[50];
	char prenom[50];
	char jour[50];
	char mois[50];
	char annee[50];
	char adresse[50];
	char tel[50];
	char adressemail[50];
	char Date[50];
	GtkWidget *output1;
	GtkWidget *output2;
	GtkWidget *output3;
	GtkWidget *output4;
	GtkWidget *output5;
	GtkWidget *output6;
	GtkWidget *output7;
	
	
    FILE *f;
    FILE *f1;
    f=fopen("baseadh.txt","r+");
    f1=fopen("ad.txt","r");
    if (f!=NULL)
    {
        while(!feof(f))
        {
	 fscanf(f1,"%s",id1);
            fscanf(f,"%s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.prenom,p.jour,
p.mois,p.annee,p.adresse,p.tel,p.adressemail);
            if(strcmp(id1,p.id)==0)
            {
strcpy(Date,p.jour);
strcat(Date,"/");
strcat(Date,p.mois);
strcat(Date,"/");
strcat(Date,p.annee);
	output1=lookup_widget(objet_graphique,"label88");
gtk_label_set_text(GTK_LABEL(output1),p.id);

output2=lookup_widget(objet_graphique,"label89");
gtk_label_set_text(GTK_LABEL(output2),p.nom);

output3=lookup_widget(objet_graphique,"label90");
gtk_label_set_text(GTK_LABEL(output3),p.prenom);

output4=lookup_widget(objet_graphique,"label91");
gtk_label_set_text(GTK_LABEL(output4),Date);

output5=lookup_widget(objet_graphique,"label92");
gtk_label_set_text(GTK_LABEL(output5),p.adresse);

output6=lookup_widget(objet_graphique,"label93");
gtk_label_set_text(GTK_LABEL(output6),p.tel);

output7=lookup_widget(objet_graphique,"label94");
gtk_label_set_text(GTK_LABEL(output7),p.adressemail);
            }
  	 
	}
	
    fclose(f1);
    fclose(f);

    }

}


void
on_button33_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
adherent p ;
	char id[50];
	char nom[50];
	char prenom[50];
	char jour[50];
	char mois[50];
	char annee[50];
	char adresse[50];
	char tel[50];
	char adressemail[50];
	char Date[50];
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *comboboxentry3;
	GtkWidget *comboboxentry4;
	GtkWidget *comboboxentry5;
	GtkWidget *input7;
	GtkWidget *input8;
	GtkWidget *input9;
	GtkWidget *output1;
	GtkWidget *output2;
	GtkWidget *output3;
	GtkWidget *output4;
	GtkWidget *output5;
	GtkWidget *output6;
	GtkWidget *output7;
        input1=lookup_widget(objet_graphique,"label88");
	input2=lookup_widget(objet_graphique,"entry27");
	input3=lookup_widget(objet_graphique,"entry28");
	input7=lookup_widget(objet_graphique,"entry29");
	input8=lookup_widget(objet_graphique,"entry30");
	input9=lookup_widget(objet_graphique,"entry31");
	comboboxentry3= lookup_widget(objet_graphique, "comboboxentry3");
	strcpy(p.jour,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry3)));
	comboboxentry4= lookup_widget(objet_graphique, "comboboxentry4");
	strcpy(p.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry4)));
	comboboxentry5= lookup_widget(objet_graphique, "comboboxentry5");
	strcpy(p.annee,gtk_combo_box_get_active_text(GTK_COMBO_BOX(comboboxentry5)));

strcpy(p.id,gtk_label_get_text(GTK_ENTRY(input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(p.tel,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(p.adressemail,gtk_entry_get_text(GTK_ENTRY(input9)));

modif_ad(p) ;
//jkbk//
strcpy(Date,p.jour);
strcat(Date,"/");
strcat(Date,p.mois);
strcat(Date,"/");
strcat(Date,p.annee);

output1=lookup_widget(objet_graphique,"label88");
gtk_label_set_text(GTK_LABEL(output1),p.id);

output2=lookup_widget(objet_graphique,"label89");
gtk_label_set_text(GTK_LABEL(output2),p.nom);

output3=lookup_widget(objet_graphique,"label90");
gtk_label_set_text(GTK_LABEL(output3),p.prenom);

output4=lookup_widget(objet_graphique,"label91");
gtk_label_set_text(GTK_LABEL(output4),Date);

output5=lookup_widget(objet_graphique,"label92");
gtk_label_set_text(GTK_LABEL(output5),p.adresse);

output6=lookup_widget(objet_graphique,"label93");
gtk_label_set_text(GTK_LABEL(output6),p.tel);

output7=lookup_widget(objet_graphique,"label94");
gtk_label_set_text(GTK_LABEL(output7),p.adressemail);

}


void
on_button34_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f;
	adherent p ;
	char id1[50];
	char id[50];
	char nom[50];
	char prenom[50];
	char jour[50];
	char mois[50];
	char annee[50];
	char adresse[50];
	char tel[50];
	char adressemail[50];
	GtkWidget *entry27;
	GtkWidget *entry28;
	GtkWidget *entry29;
	GtkWidget *entry30;
	GtkWidget *entry31;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *comboboxentry3;
	GtkWidget *comboboxentry4;
	GtkWidget *comboboxentry5;
	
    FILE *f1;
    f=fopen("baseadh.txt","r+");
    f1=fopen("ad.txt","r");
    if (f!=NULL)
    {
        while(!feof(f))
        {
	 fscanf(f1,"%s",id1);
            fscanf(f,"%s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.prenom,p.jour,
p.mois,p.annee,p.adresse,p.tel,p.adressemail);
            if(strcmp(id1,p.id)==0){
	

       
 	input1=lookup_widget(objet_graphique,"entry27");
	input2=lookup_widget(objet_graphique,"entry28");
	input3=lookup_widget(objet_graphique,"entry29");
	input4=lookup_widget(objet_graphique,"entry30");
	input5=lookup_widget(objet_graphique,"entry31");
	comboboxentry3= lookup_widget(objet_graphique, "comboboxentry3");
	comboboxentry4= lookup_widget(objet_graphique, "comboboxentry4");
	comboboxentry5= lookup_widget(objet_graphique, "comboboxentry5");
	gtk_entry_set_text (GTK_ENTRY (input1), p.nom);
	gtk_entry_set_text (GTK_ENTRY (input2), p.prenom);
	gtk_entry_set_text (GTK_ENTRY (input3), p.adresse);
	gtk_entry_set_text (GTK_ENTRY (input4), p.tel);
	gtk_entry_set_text (GTK_ENTRY (input5), p.adressemail);
	gtk_entry_set_text (GTK_ENTRY (comboboxentry3), p.jour);
	gtk_entry_set_text (GTK_ENTRY (comboboxentry4), p.mois);
	gtk_entry_set_text (GTK_ENTRY (comboboxentry5), p.annee);



 fclose(f);
fclose(f1);
}
}
}
}


void
on_button35_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox6;
char coach[50];
combobox6=lookup_widget(objet_graphique, "combobox6");
strcpy(coach,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox6)));
ajouter_res(coach);

}


void
on_button36_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox6;
char coach[50];
char horraire[50];
combobox6=lookup_widget(objet_graphique, "combobox6");
FILE* f=fopen("reservation.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s \n",coach,horraire)!=EOF)
{
strcat(coach,horraire);
gtk_combo_box_append_text (GTK_COMBO_BOX (combobox6), _(coach));
}
fclose(f);
}
}


void
on_button38_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox7;
char coach[50];
combobox7=lookup_widget(objet_graphique, "combobox7");
FILE* f=fopen("coach.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s\n",coach)!=EOF)
{
gtk_combo_box_append_text (GTK_COMBO_BOX (combobox7), _(coach));
}
fclose(f);
}
}


void
on_button37_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox7;
char coach[50];
combobox7=lookup_widget(objet_graphique, "combobox7");
strcpy(coach,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox7)));
supprimer_res(coach);
}


void
on_button39_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *treeview3;


treeview3 = lookup_widget(objet_graphique,"treeview3");
afficher (treeview3);

}


void
on_button40_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button11_clicked(GtkWidget *objet_graphique,gpointer user_data)

{
	GtkWidget *input;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *output;
	GtkWidget *window_modifier_adherent;
	GtkWidget *window_gestion_adherent;
	Adherent P;
	Adherent A;
   	FILE *f9;
	char id[50];
	char error[100];
	input=lookup_widget(objet_graphique,"entry7");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));
	if (verifier(id)==1)
	{
		window_gestion_adherent=lookup_widget(objet_graphique,"window_gestion_adherent");
		gtk_widget_hide(window_gestion_adherent);
		f9=fopen("base.txt", "r");
		if(f9!=NULL)
   	 	{
   	 	    while(fscanf(f9,"%s %s %s %s %s",A.ID,A.password,A.role,A.nom,A.prenom)!=EOF)
   	 	    {
   	 	        if(strcmp(id,A.ID)==0)
   	 	        {
				window_modifier_adherent=create_window_modifier_adherent();
				gtk_widget_show (window_modifier_adherent);
				input1=lookup_widget(window_modifier_adherent,"entry10");
				input2=lookup_widget(window_modifier_adherent,"entry13");
				input3=lookup_widget(window_modifier_adherent,"entry14");
				input4=lookup_widget(window_modifier_adherent,"entry11");
				input5=lookup_widget(window_modifier_adherent,"entry12");
				gtk_entry_set_text (GTK_ENTRY (input1),A.ID);
				gtk_entry_set_text (GTK_ENTRY (input2),A.password);
				gtk_entry_set_text (GTK_ENTRY (input3),A.role);
				gtk_entry_set_text (GTK_ENTRY (input4),A.nom);
				gtk_entry_set_text (GTK_ENTRY (input5),A.prenom);
				}
   	 	    }
   	 	}
	}
	else if (verifier(id)==0)
	{
		strcpy(error,"Adherent inexistant! Vérifiez S.V.P.");
		output=lookup_widget(objet_graphique,"label25");
		gtk_label_set_text(GTK_LABEL(output),error);
	}
}

						

void
on_button48_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button49_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button50_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button51_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button52_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button53_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button54_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button56_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button57_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button58_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button61_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button60_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button59_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button64_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button62_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button63_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button65_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button70_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button68_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button69_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button67_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button71_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button72_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button73_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}

