#ifndef ADHERENT_H_INCLUDED
#define ADHERENT_H_INCLUDED

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



struct Adherent
{

   char ID[50];
   char password[50];
   char role[50];
   char nom[50];
   char prenom[50];
 
};
typedef struct Adherent Adherent;

void ajouter_adherent();
int modifier_adherent();
int rechercher_adherent();
void supprimer_adherent();
int verifier();
int verifierlog (char Login[], char Password[]);
void afficher_adherent(GtkWidget *treeview1);
#endif
