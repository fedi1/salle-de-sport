#ifndef MEDECIN_H_INCLUDED
#define MEDECIN_H_INCLUDED

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



struct Medecin
{

   char ID[50];
   char password[50];
   char role[50];
   char nom[50];
   char prenom[50];
 
};
typedef struct Medecin Medecin;

void ajouter_medecin();
int modifier_medecin();
int rechercher_medecin();
void supprimer_medecin();
int verifier_medecin();
void afficher_medecin(GtkWidget *treeview3);
#endif
