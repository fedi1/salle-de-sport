#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include "medecin.h"
#include<string.h>

void ajouter_medecin(Medecin A)
{
FILE *f;
FILE *f1;
f=fopen("base_med.txt","a+");
        if(f!=NULL)
        { 
	fprintf(f,"%s %s %s %s %s\n",A.ID,A.password,A.role,A.nom,A.prenom);
	fclose(f);
	}
	else
	{
	printf("Impossible d'ouvrir le fichier");
	}
f1=fopen("liste.txt","a+");
        if(f!=NULL)
        { 
	fprintf(f,"%s %s %s %s %s\n",A.ID,A.password,A.role,"","");
	fclose(f);
	}
	else
	{
	printf("Impossible d'ouvrir le fichier");
	}
}

int rechercher_medecin(char id[50])
{    
	FILE *f;
	Medecin p;
	int y=0;
	f=fopen("base_med.txt","r");
	if(f==NULL)
	{
		return -1;
	}
	while(fscanf(f,"%s %s %s %s %s\n",p.ID,p.password,p.role,p.nom,p.prenom)!=EOF)
	{
        	y++;
		if(strcmp(p.ID,id)==0)
		{
			fclose(f);
			return y;
		}
	}	
	fclose(f);
	return 0;	
}

int modifier_medecin(Medecin A)
{
Medecin p;
    FILE *f;
    FILE *f1;
    f1=NULL;
    f=fopen("base_med.txt","r+");
    f1=fopen("base_med.txt.tmp","a+");
    if (f!=NULL)
    {
        while(!feof(f))
        {
            fscanf(f,"%s %s %s %s %s\n",p.ID,p.password,p.role,p.nom,p.prenom);
            if(strcmp(p.ID,A.ID)!=0)
            {
			fprintf(f1,"%s %s %s %s %s\n",p.ID,p.password,p.role,p.nom,p.prenom);
            }
  	    else
            {
	     		fprintf(f1,"%s %s %s %s %s\n",A.ID,A.password,A.role,A.nom,A.prenom);
	    }	
	}
    fclose(f1);
    fclose(f);
    rename("base_med.txt.tmp","base_med.txt");
	return 0;

}
}

void supprimer_medecin(char id[50])
{
Medecin A;
FILE *f;
FILE *f2;
FILE *f5;
FILE *f6;
f=fopen("base_med.txt","r");

if(f==NULL)
	{
		printf("erreur d'ouverture du fichier ");
		return;
	}
while (fscanf(f,"%s %s %s %s %s\n",A.ID,A.password,A.role,A.nom,A.prenom)!=EOF)
        {
         if (strcmp(id,A.ID))
        {
	f2=fopen("base1_med.txt", "a");
		if (f2==NULL)
		{
		printf("erreur d'ouverture du fichier en mode a");
		return;
		}

	fprintf(f2,"%s %s %s %s %s\n",A.ID,A.password,A.role,A.nom,A.prenom);

	 fclose(f2);
	}
	}

	fclose(f);
remove("base_med.txt");
rename("base1_med.txt","base_med.txt");

f5=fopen("liste.txt","r");

if(f5==NULL)
	{
		printf("erreur d'ouverture du fichier ");
		return;
	}
while (fscanf(f5,"%s %s %s\n",A.ID,A.password,A.role)!=EOF)
        {
         if (strcmp(id,A.ID))
        {
	f6=fopen("liste1.txt", "a");
		if (f6==NULL)
		{
		printf("erreur d'ouverture du fichier en mode a");
		return;
		}

	fprintf(f6,"%s %s %s\n",A.ID,A.password,A.role);

	 fclose(f6);
	}
	}

	fclose(f5);
remove("liste.txt");
rename("liste1.txt","liste.txt");

}

int verifier_medecin(char id[50])
{
	int res=0;
	Medecin A;
	FILE *f;
	f=fopen("base_med.txt","r");
	if(f!=NULL)
	{
		while (fscanf(f,"%s %s %s %s %s\n",A.ID,A.password,A.role,A.nom,A.prenom)!=EOF)
		{
			if(strcmp(id,A.ID)==0)
			{
				res=1;
				break;
			}
		}
	return res;
	}
}



enum
{
	
	Med_ID,
	Password,
        Role,
	Nom,
	Prenom,
	COLUMNS
};

void afficher_medecin(GtkWidget *treeview2)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
	
	//long int d2;
	char Id[50];
        char password[50];
        char role[50];
	char lastname[50];
	char name[50]; 
	FILE *f;
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Medecin ID", renderer, "text",Med_ID, NULL);	
	gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);	

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Password", renderer, "text", Password, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Rôle", renderer, "text",Role, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text",Nom, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);

	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("Prénom", renderer, "text",Prenom, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (treeview2), column);
	


	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	
	f = fopen("base_med.txt", "r");
	
	if(f ==NULL)
	{
		printf("erreur d'ouverture ");
		return;
	}		
	else
	{
		
		while(fscanf(f,"%s %s %s %s %s\n",Id,password,role,lastname,name)!=EOF)
		{      
			
			gtk_list_store_append (store, &iter);
			gtk_list_store_set (store, &iter,Med_ID,Id,Password,password,Role,role,Nom,lastname,Prenom, name,-1);
			
					
		}
		
		fclose(f);
		
	}
		
	gtk_tree_view_set_model (GTK_TREE_VIEW (treeview2), GTK_TREE_MODEL (store));
	
	g_object_unref (store);
}



