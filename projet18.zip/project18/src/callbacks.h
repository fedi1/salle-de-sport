#include <gtk/gtk.h>


void
on_button1_clicked (GtkWidget *objet_graphique,gpointer user_data);

void
on_button2_clicked(GtkWidget *objet_graphique,gpointer user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked (GtkWidget *objet_graphique,gpointer user_data);

void
on_button10_clicked(GtkWidget *objet_graphique,gpointer  user_data);

void
on_button12_clicked (GtkWidget *objet_graphique,gpointer user_data);

void
on_button13_clicked(GtkWidget *objet_graphique,gpointer user_data);

void
on_button14_clicked (GtkButton  *button,gpointer  user_data);

void
on_button8_clicked (GtkWidget *objet_graphique,gpointer user_data);

void
on_button15_clicked  (GtkWidget *objet_graphique,gpointer user_data);

void
on_button16_clicked (GtkWidget  *button,gpointer  user_data);

void
on_button28_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button32_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button33_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button34_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button35_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button36_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button38_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button37_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button39_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button11_clicked(GtkWidget *objet_graphique,gpointer user_data);

void
on_button48_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button49_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button50_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button51_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button52_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button53_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button54_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button56_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button57_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button58_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button61_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button60_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button59_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button64_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button62_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button63_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button65_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button70_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button68_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button69_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button67_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button71_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button72_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button73_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
